"""Planner (PRD F2.1a–b): Campaign Spec → daftar wilayah & query pencarian, tanpa seed list."""
from __future__ import annotations

from . import wilayah
from .campaign import CampaignSpec

# Pola query transaksi spesifik (Fokus transaksi nyata, bukan sekadar obrolan)
GROUP_PATTERNS_SUPPLY = [
    "jual {p} {r}",
    "panen {p} {r}",
    "ready {p} {r}",
    "petani {p} {r}"
]

GROUP_PATTERNS_DEMAND = [
    "cari {p} {r}",
    "butuh {p} {r}",
    "tampung {p} {r}",
    "beli {p} {r}"
]

# Pola pencarian Google Maps / Bisnis Lokal untuk calon pembeli B2B (PRD §7.2 F2.1d)
PLACES_PATTERNS = [
    "toko buah {r}",
    "toko sayur {r}",
    "distributor buah {r}",
    "pasar induk {r}",
    "grosir buah {r}",
]

# Pola pencarian Direktori Web B2B & Kemitraan Agribisnis (PRD §7.2 F2.2)
WEB_B2B_PATTERNS = [
    "supplier {p} {r}",
    "distributor {p} {r}",
    "kemitraan pasokan {p} {r}",
]

PROVINCE_PATTERNS = [
    "jual {p} {prov}",
    "panen {p} {prov}",
    "komunitas {p} {prov}"
]

INTENT_WORDS = {
    "supply": ["jual", "panen", "ready", "stok", "borongan"],
    "demand": ["cari", "butuh", "terima", "beli", "tampung"],
}

# Kata kunci negatif untuk menyaring sampah dari Google Search
NEGATIVE_KEYWORDS = "-bibit -benih -pupuk -obat -loker -lowongan -resep -jus -olahan -jasa -mesin"


def expand_regions(spec: CampaignSpec) -> list[dict]:
    """Provinsi dipecah menjadi kabupaten/kota. Urutan: prioritas operator → sisanya.

    Catatan: PRD F2.1a meminta prioritas sentra produksi dicari otomatis dari data BPS/dinas.
    Itu dijadwalkan di M3; sementara ini operator bisa mengisi `location.priority`.
    """
    regions: list[dict] = []
    seen: set[str] = set()
    excluded = {r["kode"] for x in spec.location.exclude for r in wilayah.find_regions_in_text(x)}

    def add(r: dict) -> None:
        if r["kode"] not in seen and r["kode"] not in excluded:
            seen.add(r["kode"])
            regions.append(r)

    for name in spec.location.priority:
        r = wilayah.find_region_by_name(name)
        if r:
            add(r)
    for item in spec.location.include:
        prov = wilayah.resolve_province(item)
        if prov:
            for r in wilayah.regions_of(prov):
                add(r)
        else:
            for r in wilayah.find_regions_in_text(item):
                add(r)
    return regions


def build_group_queries(spec: CampaignSpec, max_queries: int | None = None) -> list[dict]:
    """Query untuk pencarian grup FB. Nama kota & kabupaten yang sama (Kediri) cukup sekali."""
    p = (spec.product.name or "").lower()
    if not p:
        return []
    patterns = GROUP_PATTERNS_DEMAND if spec.target_intent == "demand" else GROUP_PATTERNS_SUPPLY
    queries: list[dict] = []
    seen: set[str] = set()

    def add(q: str, region: str, platform: str = "facebook", kind: str = "group_search") -> None:
        q = " ".join(q.lower().split())
        if q not in seen:
            seen.add(q)
            queries.append({"query": q, "region": region, "platform": platform, "kind": kind})

    for prov in spec.provinces():
        for pat in PROVINCE_PATTERNS:
            add(pat.format(p=p, prov=prov), prov, "facebook", "group_search")
            
    regions = expand_regions(spec)
    for r in regions:
        # 1. Grup Facebook (Petani / Penjual / Pembeli medsos)
        for pat in patterns:
            add(pat.format(p=p, r=r["nama"]), wilayah.label(r), "facebook", "group_search")

        # 2. Google Maps / Bisnis Lokal (Toko Buah, Toko Sayur, Distributor, Pasar Induk)
        for pat in PLACES_PATTERNS:
            add(pat.format(r=r["nama"]), wilayah.label(r), "google_maps", "places_search")

        # 3. Web B2B & Kemitraan Agribisnis
        for pat in WEB_B2B_PATTERNS:
            add(pat.format(p=p, r=r["nama"]), wilayah.label(r), "web_b2b", "web_search")
            
    # FALLBACK 1: Jika lokasi tidak ada di database wilayah.json (misal luar Jawa Timur),
    # gunakan teks lokasi mentah yang diinputkan dari spec.location.include
    if not regions and not spec.provinces() and spec.location.include:
        for loc in spec.location.include:
            for pat in patterns:
                add(pat.format(p=p, r=loc), loc, "facebook", "group_search")
            for pat in PLACES_PATTERNS:
                add(pat.format(r=loc), loc, "google_maps", "places_search")


    # FALLBACK 2: Jika user SAMA SEKALI tidak menyebutkan lokasi (lokasi kosong),
    # buat query skala nasional agar pipeline tidak macet!
    if not queries:
        for w in INTENT_WORDS.get(spec.target_intent, ["jual", "panen"]):
            add(f"{w} {p}", "Indonesia (Nasional)")
        add(f"petani {p}", "Indonesia (Nasional)")
        add(f"komunitas {p}", "Indonesia (Nasional)")

    for syn in spec.product.synonyms:
        if syn.lower() != p:
            for prov in spec.provinces():
                add(f"{syn} {prov}", prov)
            if not spec.provinces():
                add(f"jual {syn}", "Indonesia (Nasional)")
    return queries[:max_queries] if max_queries else queries


def build_post_keywords(spec: CampaignSpec) -> list[str]:
    """Kata kunci untuk pencarian di dalam grup (misal 'jual melon')."""
    p = (spec.product.name or "").lower()
    return [f"{w} {p}" for w in INTENT_WORDS[spec.target_intent]] if p else []
